#include <iostream>
#include "DateCal.h"

using std::cout;
using std::endl;

void main() {
	

	cout << dateCal("2017:10:23:20:59", "2017:10:23:24:51") << endl;

}